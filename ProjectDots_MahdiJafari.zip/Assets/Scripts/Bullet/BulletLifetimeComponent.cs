using Unity.Entities;

public struct BulletLifetimeComponent : IComponentData
{
    public float RemainingLifeTime;    
}
